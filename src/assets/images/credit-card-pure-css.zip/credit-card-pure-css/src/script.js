/*
  Inspired by: "Credit card design"
  By: Brice Corbin
  Link: https://dribbble.com/shots/4268384-Credit-card-design
*/